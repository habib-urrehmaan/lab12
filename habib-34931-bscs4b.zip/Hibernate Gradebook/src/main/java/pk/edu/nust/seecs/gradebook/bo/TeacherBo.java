/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.bo;

import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Teacher;

/**
 *
 * @author habib
 */
public class TeacherBo {
    TeacherDao tDao;

	public void setTeacherDao(TeacherDao tDao) {
		this.tDao = tDao;
	}

	public void save(Teacher teacher){
		tDao.addTeacher(teacher);
	}

	public void update(Teacher teacher){
		tDao.updateTeacher(teacher);
	}

	public void delete(Teacher teacher){
		tDao.deleteTeacher(teacher.getTeacherId());
	}
}
