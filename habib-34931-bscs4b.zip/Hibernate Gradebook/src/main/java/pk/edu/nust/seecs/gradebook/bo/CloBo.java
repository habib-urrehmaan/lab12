package pk.edu.nust.seecs.gradebook.bo;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author habib
 */
public class CloBo {
    	CloDao cloDao;

	public void setCloDao(CloDao cloDao) {
		this.cloDao = cloDao;
	}

	public void save(Clo clo){
		cloDao.addClo(clo);
	}

	public void update(Clo clo){
		cloDao.updateClo(clo);
	}

	public void delete(Clo clo){
		cloDao.deleteClo(clo.getCloId());
	}
}
