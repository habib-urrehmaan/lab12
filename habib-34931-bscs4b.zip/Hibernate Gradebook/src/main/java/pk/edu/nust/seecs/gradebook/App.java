package pk.edu.nust.seecs.gradebook;
//import java.sql.SQLException;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.GregorianCalendar;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
import pk.edu.nust.seecs.gradebook.bo.CloBo;
//import pk.edu.nust.seecs.gradebook.dao.CloDao;
//import pk.edu.nust.seecs.gradebook.dao.ContentDao;
//import pk.edu.nust.seecs.gradebook.dao.CourseDao;
//import pk.edu.nust.seecs.gradebook.dao.GradeDao;
//import pk.edu.nust.seecs.gradebook.dao.StudentDao;
//import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
//import pk.edu.nust.seecs.gradebook.entity.Content;
//import pk.edu.nust.seecs.gradebook.entity.Course;
//import pk.edu.nust.seecs.gradebook.entity.Grade;
//import pk.edu.nust.seecs.gradebook.entity.Student;
//import pk.edu.nust.seecs.gradebook.entity.Teacher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    public static void main(String[] args) {
///////////////////////////////
//////////           //////////
/////////ADDING DATA//////////
////////           //////////
////////////////////////////
        //Adding Clo Data
//        CloDao clodao = new CloDao();
//        Clo clo=new Clo();
//        
//        clo.setBtLevel("PGCS");
//        clo.setDescription("Research Computers");
//        clo.setName("Clo 5");
//        clo.setPlo("plo 1");
//        clodao.addClo(clo);
//        
//        //Adding Content Data
//        ContentDao contdao=new ContentDao();
//        Content cont=new Content();
//        
//        //cont.setCourse(course);
//        Calendar cal = Calendar.getInstance();
//        Calendar cal2=Calendar.getInstance();
//        cal.set(Calendar.HOUR_OF_DAY,14);
//        cal.set(Calendar.MINUTE,30);
//        cal.set(Calendar.SECOND,0);
//        cal.set(Calendar.MILLISECOND,0);
//        
//        cal2.set(Calendar.HOUR_OF_DAY,17);
//        cal2.set(Calendar.MINUTE,30);
//        cal2.set(Calendar.SECOND,0);
//        cal2.set(Calendar.MILLISECOND,0);
//
//        Date d1=cal2.getTime();
//        Date d = cal.getTime();
//        
//        cont.setDescription("Related to Programming");
//        cont.setEndtime(d1);
//        cont.setStarttime(d);
//        //cont.setStudents("");
//        cont.setTitle("Advance Programming");
//        contdao.addContent(cont);
//        
//        //Adding Grade data
//        GradeDao grddao=new GradeDao();
//        Grade grd=new Grade();
//        
//        grd.setName("A");
//        grd.setScore(80);
//        grd.setContentItem(cont);
//        grddao.addGrade(grd);
//        
//        //Adding Course Data
//        int iter;
//        CourseDao courdao=new CourseDao();
//        Course cour=new Course();
//        
//        cour.setClasstitle("Advance Programming");
//        cour.setCreditHours(4);
//        cour.setEndsOn(new GregorianCalendar(2014, Calendar.FEBRUARY, 11).getTime());
//        cour.setStartsOn(new GregorianCalendar(2013, Calendar.DECEMBER, 11).getTime());
//        courdao.addCourse(cour);
//        
//        //Adding Teachers data
//        Teacher teacher=new Teacher();
//        TeacherDao teacherdao=new TeacherDao();
//        
//        teacher.setName("Arsalan Ahmed");
//        teacherdao.addTeacher(teacher);
//        
//        
//        //Adding Student Data
//        StudentDao stddao=new StudentDao();
//        Student std=new Student();
//        
//        std.setName("Nausherwan");
//        stddao.addStudent(std);
//        
//        
////**************************//
////****               ******//
////****RETRIEVING DATA*****//
////****               ****//    
////**********************//    
//
//        

ApplicationContext appContext = new ClassPathXmlApplicationContext("src/main/resources/config/BeanLocations.xml");

    	CloBo cloBo = (CloBo)appContext.getBean("cloBo");

    	/** insert **/
    	Clo clo = new Clo();
    	clo.setName("clo1");
    	clo.setBtLevel("2K15");
    	clo.setDescription("nothing to do");
        clo.setPlo("plo3");

    	System.out.println("Done");


    }

}